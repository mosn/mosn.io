---
title: "connection_manager"
linkTitle: "connection_manager"
date: 2020-01-20
weight: 2
aliases: "/zh/docs/configuration/server/listener/network-filter/connection-manager"
description: >
  Network Filter 中的 connection_manager  配置说明。
---

`connection_manager` 用于描述 MOSN 的路由配置，通常与 proxy 配合使用。配置详细描述见[router](../../../router)

注意：这是一个已经废弃的配置项。依然保留它的存在，是为了兼容性考虑。
新的配置模式下，应该配置在[server](../../../../server)的routers中


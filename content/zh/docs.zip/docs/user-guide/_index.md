---
title: "开始"
linkTitle: "开始"
weight: 2
aliases: "/zh/docs/quick-start/"
date: 2020-01-20
description: >
  快速搭建开发环境作为独立代理或在 Istio 中运行。
---



---
title: "编码规范"
linkTitle: "编码规范"
date: 2021-09-08
aliases: "/zh/docs/dev/code-review"
weight: 2
description: >
  本页介绍MOSN的编码规范。
---

## MOSN编码规范
Go Code Review Comments https://github.com/golang/go/wiki/CodeReviewComments
